#!/usr/bin/env bash
# -*- coding: utf-8 -*-
# region header
# Copyright Torben Sickert (info["~at~"]torben.website) 16.12.2012

# License
# -------

# This library written by Torben Sickert stand under a creative commons naming
# 3.0 unported license. See https://creativecommons.org/licenses/by/3.0/deed.de
# endregion
source ./bashlink/module.sh
bl.module.import bashlink.logging

if [[ "$*" != '' ]] && [[ "$*" != UNKNOWN ]]; then
    if (( HOST_USER_ID == 0 )); then
        bl.logging.info "Run command \"$*\" as root user."

        eval "$*"
        exit $?
    fi

    bl.logging.info \
        "Run command \"$*\" as user \"${MAIN_USER_NAME}\" in group" \
        "\"${MAIN_USER_GROUP_NAME}\"."

    exec su "$MAIN_USER_NAME" --group "$MAIN_USER_GROUP_NAME" -c "$*"
fi
# region vim modline
# vim: set tabstop=4 shiftwidth=4 expandtab:
# vim: foldmethod=marker foldmarker=region,endregion:
# endregion
