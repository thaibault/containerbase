#!/usr/bin/env bash
# -*- coding: utf-8 -*-
# region header
# Copyright Torben Sickert (info["~at~"]tsickert.com) 16.12.2012

# License
# -------

# This library written by Torben Sickert stands under a creative commons naming
# 4.0 international license.
# See https://creativecommons.org/licenses/by/4.0/deed.de
# endregion
# shellcheck source=SCRIPTDIR/get-bashlink.sh
source get-bashlink

if [[ "$*" != '' ]] && [[ "$*" != UNKNOWN ]]; then
    if (( HOST_USER_ID == 0 )); then
        bl.logging.info "Run command \"$*\" as root user."

        eval "$*"
        exit $?
    fi

    bl.logging.info \
        "Run command \"$*\" as user \"${MAIN_USER_NAME}\" in group" \
        "\"${MAIN_USER_GROUP_NAME}\"."

    exec su --group "$MAIN_USER_GROUP_NAME" "$MAIN_USER_NAME" -c "$*"
fi
# region vim modline
# vim: set tabstop=4 shiftwidth=4 expandtab:
# vim: foldmethod=marker foldmarker=region,endregion:
# endregion
