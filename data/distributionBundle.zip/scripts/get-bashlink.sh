#!/usr/bin/env bash
# -*- coding: utf-8 -*-
# region header
# [Project page](https://tsickert.com/containerbase)

# Copyright Torben Sickert (info["~at~"]tsickert.com) 16.12.2012

# License
# -------

# This library written by Torben Sickert stands under a creative commons naming
# 4.0 international license.
# See https://creativecommons.org/licenses/by/4.0/deed.de
# endregion
# shellcheck disable=SC1004,SC2016,SC2034,SC2155
shopt -s expand_aliases
alias cb.download=cb_download
cb_download() {
    local -r __documentation__='
        Simply downloads missing modules.

        >>> cb.download --silent https://domain.tld/path/to/file.ext; echo $?
        6
    '
    command curl --insecure "$@"
    return $?
}

if [ -f "$(dirname "${BASH_SOURCE[0]}")/node_modules/bashlink/module.sh" ]; then
    # shellcheck source=SCRIPTDIR/../node_modules/bashlink/module.sh
    source "$(dirname "${BASH_SOURCE[0]}")/node_modules/bashlink/module.sh"
else
    declare -g CB_BASHLINK_PATH=/usr/lib/bashlink/
    if [ -f "${CB_BASHLINK_PATH}module.sh" ]; then
        # shellcheck source=SCRIPTDIR/../node_modules/bashlink/module.sh
        source "${CB_BASHLINK_PATH}module.sh"
    else
        mkdir --parents "$CB_BASHLINK_PATH"
        declare -gr BL_MODULE_RETRIEVE_REMOTE_MODULES=true
        declare -gr BL_MODULE_AVOID_TIDY_UP_PATH=true
        if ! (
            [ -f "${CB_BASHLINK_PATH}module.sh" ] || \
            cb.download \
                https://raw.githubusercontent.com/thaibault/bashlink/main/module.sh \
                    >"${CB_BASHLINK_PATH}module.sh"
        ); then
            echo Needed bashlink library could not be retrieved. 1>&2
            rm --force --recursive "$CB_BASHLINK_PATH"
            exit 1
        fi
        # shellcheck source=SCRIPTDIR/../node_modules/bashlink/module.sh
        source "${CB_BASHLINK_PATH}module.sh"
    fi
fi

bl.module.import bashlink.logging
bl.logging.set_level info

# region vim modline
# vim: set tabstop=4 shiftwidth=4 expandtab:
# vim: foldmethod=marker foldmarker=region,endregion:
# endregion
