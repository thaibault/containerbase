#!/usr/bin/env bash
# -*- coding: utf-8 -*-
# region header
# [Project page](https://tsickert.com/containerbase)

# Copyright Torben Sickert (info["~at~"]tsickert.com) 16.12.2012

# License
# -------

# This library written by Torben Sickert stands under a creative commons naming
# 4.0 international license.
# See https://creativecommons.org/licenses/by/4.0/deed.de
# endregion
# shellcheck source=SCRIPTDIR/get-bashlink.sh
source get-bashlink

for package in "$@"; do
    if pacman-wrapper --query --info "$package" &>/dev/null; then
        bl.logging.info "Remove package ${package}."

        pacman-wrapper --remove --noconfirm --recursive --nosave "$package"
    fi
done

if pacman-wrapper --query --deps --unrequired --quiet; then
    orphans="$(
        pacman-wrapper --query --deps --unrequired --quiet | \
            tr '\n' ' ' | \
            sed --regexp-extended 's/.*->.+\. (.+)/\1/'
    )"
    bl.logging.info "Remove unneeded packages: ${orphans}."
    # shellcheck disable=SC2086
    pacman-wrapper --remove --noconfirm --recursive --nosave $orphans
fi

# NOTE: We should avoid leaving unnecessary data in that layer.
if (( UID == 0 )); then
    rm /var/cache/* --recursive --force
else
    sudo rm /var/cache/* --recursive --force
fi
# region vim modline
# vim: set tabstop=4 shiftwidth=4 expandtab:
# vim: foldmethod=marker foldmarker=region,endregion:
# endregion
